package tasarimcigurkan.dev.imgbtnprj;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

//import tasarimcigurkan.dev.imgbtnprj.R;

public class MainActivity extends Activity {
    ImageButton imgBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        addListenerImgBtn();
    }
    
    /*****************************/
    
    public void addListenerImgBtn(){
      imgBtn=findViewById(R.id.imgBtn);
      imgBtn.setOnClickListener(new OnClickListener(){
        @Override
        public void onClick(View v){
          Toast.makeText(getApplicationContext(), "tıklandı", Toast.LENGTH_SHORT).show();
        }
      });}
    
    /****************************/
}
