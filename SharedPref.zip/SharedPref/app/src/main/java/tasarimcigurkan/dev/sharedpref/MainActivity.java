package tasarimcigurkan.dev.sharedpref;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;


public class MainActivity extends Activity 
{

	EditText kullanici;
	EditText gizce;
	Button kaydet;
	Button okuBtn;
	TextView rapor;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		kullanici=(EditText)findViewById(R.id.kullanici);
		gizce=(EditText)findViewById(R.id.gizce);
		kaydet=(Button)findViewById(R.id.kaydet);
		okuBtn=(Button)findViewById(R.id.okuBtn);
		rapor=(TextView)findViewById(R.id.rapor);
		/******************************************************************/
		kaydet.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				try{

					SharedPreferences tercihDosyasi=getSharedPreferences("kullaniciBilgileri",Context.MODE_PRIVATE);
					SharedPreferences.Editor editor=tercihDosyasi.edit();
					editor.putString("kullanici_adi",kullanici.getText().toString());
					editor.putString("sifre",gizce.getText().toString());
					editor.apply();

					Toast.makeText(getApplicationContext(),
								   "Kullanıcı adı ve şifrenizi değiştirdiniz!",
								   Toast.LENGTH_LONG).show();

				}catch(Exception e){Log.e("Dosya bağlantı hatası", "hata oluştu");}
			}
		});
		/*******************************************************************/
		okuBtn.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					try{

						SharedPreferences dosya=getSharedPreferences("kullaniciBilgileri",Context.MODE_PRIVATE);
						String kullanici=dosya.getString("kullanici_adi","").toString();
						String gizce=dosya.getString("sifre","").toString();
						
						rapor.setText(kullanici+ "\n" +gizce);

						Toast.makeText(getApplicationContext(),
									   "Kullanıcı adı ve şifrenizi hacklediniz!",
									   Toast.LENGTH_LONG).show();

					}catch(Exception e){Log.e("Dosya bağlantı hatası", "hata oluştu");}
				}
			});
		/*******************************************************************/
    }
}

/****************** İNCELEME ********************************

	kaydet=(Button)findViewById(R.id.kaydet);
	kaydet.setOnClickListener(new View.OnClickListener(){
	@Override
	public void onClick(View v){
		try{

			SharedPreferences tercihDosyasi=getSharedPreferences("kullaniciBilgileri",Context.MODE_PRIVATE);
			SharedPreferences.Editor editor=tercihDosyasi.edit();
			editor.putString("kullanici_adi",kullanici.getText().toString());
			editor.putString("sifre",gizce.getText().toString());
			editor.apply();

			Toast.makeText(getApplicationContext(),
						   "Kullanıcı adı ve şifrenizi değiştirdiniz!",
						   Toast.LENGTH_LONG).show();

		}catch(Exception e){Log.e("Dosya bağlantı hatası", "hata oluştu");}
	}
	});
	
	-------------------------------------------------------------------
	
	okuBtn=(Button)findViewById(R.id.okuBtn);
	okuBtn.setOnClickListener(new View.OnClickListener(){
	@Override
	public void onClick(View v){
		try{

			SharedPreferences dosya=getSharedPreferences("kullaniciBilgileri",Context.MODE_PRIVATE);
			String kullanici=dosya.getString("kullanici_adi","").toString();
			String gizce=dosya.getString("sifre","").toString();

			rapor.setText(kullanici+ "\n" +gizce);

			Toast.makeText(getApplicationContext(),
						   "Kullanıcı adı ve şifrenizi hacklediniz!",
						   Toast.LENGTH_LONG).show();

		}catch(Exception e){Log.e("Dosya bağlantı hatası", "hata oluştu");}
	}
			});
-------------------------------------------------------------------------

	Button kaydet=(Button)findViewById(R.id.kaydet);
	kaydet.setOnClickListener(new View.OnClickListener(){
	@Override
	public void onClick(View v){
		try{

		}catch(Exception e){Log.e("hata iletisi", "hata oluştu");}
	}
	});
*************************************************************************/
