package gel.tasarimcigurkan.fiostream;

import android.app.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import android.content.*;

public class MainActivity extends Activity 
{
	private static final String DsyAd="fios_eskiz.txt";
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		/* bu sayfayı ilgilendiren bir Intent bağlantısı olduğunda 
		örneğin kaydedilmiş durum bilgileri bir bohça ile üst sınıfa aktarılıyor.*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		/* çekilen xml dosyasındaki ögeler 
		Java içinde kullanılabilmesi için Java koduna bağlanıyor.*/
		Button yazButton=findViewById(R.id.dosyayaYaz);
		Button okuButton=findViewById(R.id.dosyadanOku);
		
		final TextView yazilanMetinText=findViewById(R.id.yazilanMetin);
		final EditText eklenecekMetin=findViewById(R.id.eklenecekMetin);
		/*********************************************************/
		yazButton.setOnClickListener(
			new View.OnClickListener(){
				public void onClick(View v){
					try{
						FileOutputStream fos=openFileOutput(DsyAd,Context.MODE_PRIVATE);
						fos.write(eklenecekMetin.getText().toString().getBytes());
						
						fos.flush();
						fos.close();
						
					}catch(Exception e){Log.e("Dosya bağlantı hatası", "Yazmada hata oluştu");}
				}
			}
		); // yazButton.setOnClickListener sonu 
		
		okuButton.setOnClickListener(
			new View.OnClickListener(){
				public void onClick(View v){
					
					try{
						StringBuffer strBuf=new StringBuffer("");
						FileInputStream fis=openFileInput(DsyAd);
						InputStreamReader inputStreamReader=new InputStreamReader(fis,"UTF8");
						Reader rdr=new BufferedReader(inputStreamReader);
						int chrs=0;
						while((chrs=rdr.read())>-1){strBuf.append((char)chrs);}
						
						yazilanMetinText.setText(strBuf.toString());
						Log.i("Dosya okundu","okunan: "+strBuf.toString());
						
					}catch(Exception e){Log.e("Dosya bağlantı hatası", "Okumada hata oluştu");}
					

				}
			}
		);
    }
}

/******* DOSYAYA İŞLEMLERİ **********
Dosyaya yazma, ekleme ve dosyadan okuma.



*************************************/
